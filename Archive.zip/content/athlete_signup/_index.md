+++
date = "2016-10-17T20:18:00-07:00"
draft = false
title = "Athlete Signup" #_
+++

Sound Athletics offers the following sports: Bowling (Fall), Basketball (Winter), Track (Spring).
We provide both traditional and unified sports opportunities. Our coaching staff is trained to
provide a safe environment for our athletes. We welcome athletes of all abilities ages 8 and
over.

## How to join our team

1. Check out our [Calendar](../calendar) to see if our practices fit your schedule.
2. Complete an [Application for Participation (AFP)](../docs/AFP.pdf). Then deliver the form in person to Angela, team Secretary, at our practice. 
3. If you have any questions email us at [soundathleticspierce@gmail.com](mailto:soundathleticspierce@gmail.com) or speak to Ann, our Team Manager, at (253) 306-9239.
